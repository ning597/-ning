package pojo;

public class error {
    String Message="";
    public String getMessage(){
        return Message;
    }
    public void setMessage(String newName){
        Message = newName;
    }
}
