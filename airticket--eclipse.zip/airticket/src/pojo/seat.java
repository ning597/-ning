package pojo;

public class seat {
    String ticketno;
    String name;
    String flightno;
    String seat;
    String price;
    String date;
    String starttime;
    String endtime;
    String start;
    String end;

    public void setEnd(String end) {
        this.end = end;
    }

    public String getEnd() {
        return end;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEndtime() {
        return endtime;
    }

    public String getFlightno() {
        return flightno;
    }

    public String getPrice() {
        return price;
    }

    public String getSeat() {
        return seat;
    }

    public String getStarttime() {
        return starttime;
    }

    public String getTicketno() {
        return ticketno;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public void setFlightno(String flightno) {
        this.flightno = flightno;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public void setTicketno(String ticketno) {
        this.ticketno = ticketno;
    }

    //    String [][] Record = null;
//
//
//    public seat(){
//        Record = new String[1][1];
//    }
//
//    public String[][] getRecord() {
//        return Record;
//    }
//
//    public void setRecord(String[][] record) {
//        Record = record;
//    }


}
